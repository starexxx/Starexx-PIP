# Starexx

Starexx is an automatic dependency installer for Python scripts. It scans all Python files in the current directory and installs missing dependencies.

## Installation
```sh
pip install starexx
```

## Usage
```sh
starexx --run
```
