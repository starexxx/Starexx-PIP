from .core import scan_and_install

__version__ = "1.0.0"
